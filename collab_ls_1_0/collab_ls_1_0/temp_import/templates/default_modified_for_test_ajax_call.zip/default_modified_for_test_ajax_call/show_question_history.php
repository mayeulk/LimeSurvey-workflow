<?php

$country = $_POST['country'];
$role = $_POST['role'];
$token = $_POST['token'];
$surveyid =  $_POST['surveyid'];
$groupid =  $_POST['groupid'];
$questionid =  $_POST['questionid'];


echo "questionid from show_question_history: $questionid"

?> 
 
