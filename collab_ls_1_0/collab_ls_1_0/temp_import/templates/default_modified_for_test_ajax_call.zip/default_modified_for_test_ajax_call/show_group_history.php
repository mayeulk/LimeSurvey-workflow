<?php

//    print_r($_POST);
$country = $_POST['country'];
$role = $_POST['role'];
$token = $_POST['token'];
$surveyid =  $_POST['surveyid'];
$groupid =  $_POST['groupid'];
// $questionid =  $_POST['questionid'];

echo "From PHP file: the survey is $surveyid";
echo "</pre>";
?> 
 
