<?php
$country = $_GET['country'];
$role = $_GET['role'];
$token = $_GET['token'];
$sgq = $_GET['sqg'];

echo "Survey from preg_match: $sgq"

?> 
 
